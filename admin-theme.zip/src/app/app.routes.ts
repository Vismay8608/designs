import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./theme/layout/layout.component').then(m => m.LayoutComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./pages/dashboard/dashboard.component').then(m => m.DashboardComponent)
      },
      {
        path: 'asset-listing',
        loadComponent: () =>
          import('./pages/asset-listing/asset-listing.component').then(m => m.AssetListingComponent)
      },
      {
        path: 'asset-upload',
        loadComponent: () =>
          import('./pages/asset-upload/asset-upload.component').then(m => m.AssetUploadComponent)
      },
      {
        path: 'asset-approval',
        loadComponent: () =>
          import('./pages/asset-approval/asset-approval.component').then(m => m.AssetApprovalComponent)
      }
    ]
  }
];
