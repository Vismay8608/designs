import { Component } from '@angular/core';

interface ActivityRow {
  initials: string;
  name: string;
  email: string;
  event: string;
  status: string;
  date: string;
}

interface InventoryRow {
  icon: string;
  name: string;
  category: string;
  stock: string;
  stockClass: string;
  price: string;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent {
  readonly activity: ActivityRow[] = [
    { initials: 'AS', name: 'Alex Simmons',   email: 'alex.s@lumina.com',  event: 'Login Attempt (Success)',  status: 'Active',   date: 'Oct 24, 2023 • 14:32' },
    { initials: 'JM', name: 'Jessica Miller', email: 'jess.m@lumina.com',  event: 'Settings Updated',         status: 'Active',   date: 'Oct 24, 2023 • 12:15' },
    { initials: 'RC', name: 'Ryan Cole',      email: 'r.cole@lumina.com',  event: 'Password Changed',         status: 'Inactive', date: 'Oct 24, 2023 • 09:50' },
    { initials: 'SP', name: 'Sara Parker',    email: 's.parker@lumina.com', event: 'File Export',             status: 'Active',   date: 'Oct 23, 2023 • 18:07' }
  ];

  readonly inventory: InventoryRow[] = [
    { icon: 'laptop_mac', name: 'Lumina Pro X15',    category: 'Hardware',  stock: 'In Stock',     stockClass: 'bg-success-soft', price: '$1,299.00' },
    { icon: 'memory',     name: 'RAM Module 32GB',   category: 'Hardware',  stock: 'Low Stock',    stockClass: 'bg-danger-soft',  price: '$149.00'   },
    { icon: 'cloud',      name: 'Cloud Storage Plan',category: 'Software',  stock: 'In Stock',     stockClass: 'bg-success-soft', price: '$9.99/mo'  },
    { icon: 'headset_mic',name: 'Support License',   category: 'Services',  stock: 'On Order',     stockClass: 'bg-secondary-soft', price: '$499.00' }
  ];

  readonly bars = [40, 65, 85, 30, 55, 90, 45, 60];
  readonly months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  readonly regions = [
    { label: 'N. America', value: '$4.2M', pct: 85 },
    { label: 'Europe',     value: '$3.1M', pct: 70 },
    { label: 'Asia Pac',   value: '$5.8M', pct: 95 },
    { label: 'L. America', value: '$1.9M', pct: 45 },
    { label: 'M. East',    value: '$1.2M', pct: 30 },
    { label: 'Africa',     value: '$0.8M', pct: 20 }
  ];
}
