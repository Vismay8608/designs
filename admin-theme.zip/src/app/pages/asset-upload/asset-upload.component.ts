import { AfterViewInit, Component, ElementRef, ViewChild, computed, signal } from '@angular/core';

interface UploadedImage {
  src: string;
  name: string;
}

const IMG1 = 'https://lh3.googleusercontent.com/aida-public/AB6AXuCj82yBN9DmkCmLeXI5mn4zwGIqE0Y-NUaZfKpt4G0-A0tQtXpKyzVDII0x2lkU9jM_i5SGb-Boao7HdcJGctQ0weZNUSIWZ6oB9XDRZbGaOhduYjM_UOY8Gb2xCzgFD4beKMshtoIrSHUILCpkaZBy3_QWp8SfkHm9WWrrUfziQOzI3wB6kBPYoXfstHw1wI-5mZ2KK8T0mubXpWC03jC6NrUBaRFpNa9rFauwYV-kGTDlyAYoKuahkI0gJ6USS9Nk3CfFvc0eGIQC';
const IMG2 = 'https://lh3.googleusercontent.com/aida-public/AB6AXuAfDrp-P2ykbvediuB24JqWVpoyoBHzXcUcTw1lZuT3DWAPUbuwG9Miy5NC-LWtGpWnIJ1UtMaafLV7VcJq_CmiCJV1Y7qCy8i6RIN9xxzK2IbHufQ8QhHV3TQl3Nj4tQyOo3NYaLrpEJwpKQ17GN53OKpyeJTrk1jOPNXR93xRGZ1QVgqBo166z-GknmZ6VRxSQQKKke26D8w2UyfEd8e9ZKIG5iNaneIHPiQz1DqzNssBrN_z0glH2DtSGADee5W3gzbL-ARI54CN';
const IMG3 = 'https://lh3.googleusercontent.com/aida-public/AB6AXuDUAzUFkmOqa1yAte6v5dRApvOzDjf8I0yozgF51FuGiP5LP15TodTCa84DMnuaJJsBE2vRwcvyA6JGMg_ka4W92-83Ubth0euzF95VacD3B4dLE8tBKnGKtaAeRLCHTP_ky68eyxIs-p0X5tChMB1dUJQIjVKrFMenERco2DNntSLBz0hQSqsVXiY0e9u-T71JlaxLjLS2MHR5G8s458dEzdmFMaqNWbwYbNyf45rcT5RX924ZzcK0-Kgy-xGDQTUTWQlFhfcqCY7z';

@Component({
  selector: 'app-asset-upload',
  standalone: true,
  templateUrl: './asset-upload.component.html'
})
export class AssetUploadComponent implements AfterViewInit {
  @ViewChild('thumbGrid') thumbGridRef!: ElementRef<HTMLDivElement>;

  isDragOver     = signal(false);
  selectedMain   = signal<string | null>('turbine_main_01.jpg');
  canScrollLeft  = signal(false);
  canScrollRight = signal(true);

  readonly allImages: UploadedImage[] = [
    { src: IMG1, name: 'turbine_main_01.jpg' },
    { src: IMG2, name: 'detail_gear_vent.png' },
    { src: IMG3, name: 'panel_interface.webp' },
    { src: IMG1, name: 'turbine_side_02.jpg' },
    { src: IMG2, name: 'cooling_unit_03.png' },
    { src: IMG3, name: 'control_board_04.webp' },
    { src: IMG1, name: 'exhaust_valve_05.jpg' },
    { src: IMG2, name: 'motor_mount_06.png' },
    { src: IMG3, name: 'power_rail_07.webp' },
    { src: IMG1, name: 'frame_weld_08.jpg' },
    { src: IMG2, name: 'sensor_array_09.png' },
    { src: IMG3, name: 'cable_tray_10.webp' },
  ];

  readonly mainImage = computed(() =>
    this.allImages.find(img => img.name === this.selectedMain()) ?? this.allImages[0]
  );

  ngAfterViewInit() { this.updateScrollState(); }

  private updateScrollState() {
    const el = this.thumbGridRef.nativeElement;
    this.canScrollLeft.set(el.scrollLeft > 0);
    this.canScrollRight.set(el.scrollLeft + el.clientWidth < el.scrollWidth - 1);
  }

  onGridScroll() { this.updateScrollState(); }

  selectMain(name: string, e: Event) {
    e.stopPropagation();
    this.selectedMain.set(name);
  }

  scrollGrid(dir: 'left' | 'right') {
    this.thumbGridRef.nativeElement.scrollBy({ left: dir === 'right' ? 158 : -158, behavior: 'smooth' });
  }
  onDragOver(e: DragEvent)  { e.preventDefault(); this.isDragOver.set(true); }
  onDragLeave()             { this.isDragOver.set(false); }
  onDrop(e: DragEvent)      { e.preventDefault(); this.isDragOver.set(false); }
  openFilePicker(input: HTMLInputElement) { input.click(); }
}
