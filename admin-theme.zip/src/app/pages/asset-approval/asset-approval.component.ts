import { Component, signal, computed } from '@angular/core';

type Decision = 'approve' | 'reject' | 'revision';

@Component({
  selector: 'app-asset-approval',
  standalone: true,
  templateUrl: './asset-approval.component.html'
})
export class AssetApprovalComponent {
  selectedDecision = signal<Decision | null>(null);
  approverNotes    = signal('');

  showRevisionFields = computed(() => this.selectedDecision() === 'revision');

  setDecision(d: Decision) {
    this.selectedDecision.set(d);
  }

  onNotesInput(e: Event) {
    this.approverNotes.set((e.target as HTMLTextAreaElement).value);
  }

  submitDecision() {
    const d     = this.selectedDecision();
    const notes = this.approverNotes().trim();
    if (!d)              { alert('Please select an approval decision.');           return; }
    if (notes.length < 10) { alert('Please add approver notes (minimum 10 chars).'); return; }

    const label: Record<Decision, string> = {
      approve:  'Approved',
      reject:   'Rejected',
      revision: 'Sent for Revision'
    };
    alert(`Decision "${label[d]}" submitted successfully. The requester will be notified.`);
  }
}
