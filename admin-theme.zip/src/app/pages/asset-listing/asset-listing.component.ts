import { Component } from '@angular/core';

@Component({
  selector: 'app-asset-listing',
  standalone: true,
  templateUrl: './asset-listing.component.html'
})
export class AssetListingComponent {}
