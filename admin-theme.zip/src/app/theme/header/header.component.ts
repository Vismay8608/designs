import { Component, HostListener, computed, signal } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

interface MegaLink {
  label: string;
  icon: string;
  desc:  string;
  route?: string;
}

interface MegaSection {
  id:     string;
  label:  string;
  icon:   string;
  links:  MegaLink[];
}

interface MegaTab {
  id:          string;
  label:       string;
  icon:        string;
  groupLabel:  string;
  sections:    MegaSection[];
}

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './header.component.html'
})
export class HeaderComponent {

  /* ── Panel open/close state ──────────────────────────────── */
  notifOpen    = signal(false);
  settingsOpen = signal(false);
  profileOpen  = signal(false);
  megaOpen     = signal(false);

  /* ── Active selections ───────────────────────────────────── */
  activeMegaTab     = signal('general');
  activeMegaSection = signal('asset-management');

  /* ── Hierarchical menu data ──────────────────────────────── */
  readonly megaTabs: MegaTab[] = [
    {
      id: 'general', label: 'General', icon: 'home', groupLabel: 'General Pages',
      sections: [
        {
          id: 'asset-management', label: 'Asset Management', icon: 'inventory_2',
          links: [
            { label: 'Create Asset',     icon: 'add_circle',      desc: 'Register a new corporate asset to the inventory system.',   route: '/asset-listing'  },
            { label: 'Edit Asset',       icon: 'edit',            desc: 'Modify details of an existing registered asset.',           route: '/asset-listing'  },
            { label: 'Search & Manage',  icon: 'manage_search',   desc: 'Global asset search across all departments and locations.'  },
            { label: 'Asset Approval',   icon: 'gavel',           desc: 'Review and approve pending asset creation requests.',       route: '/asset-approval' },
            { label: 'Upload Images',    icon: 'photo_library',   desc: 'Attach photos and media to an existing asset record.',      route: '/asset-upload'   },
          ]
        },
        {
          id: 'auction-management', label: 'Auction Management', icon: 'sell',
          links: [
            { label: 'Active Auctions',  icon: 'storefront',   desc: 'Browse and manage all currently running auctions.'  },
            { label: 'Create Auction',   icon: 'add_circle',   desc: 'Schedule and configure a new asset auction.'        },
            { label: 'Bid History',      icon: 'history',      desc: 'Review complete bid records and past auction results.' },
            { label: 'Closed Auctions',  icon: 'lock',         desc: 'Archive and reports for completed auction cycles.'  },
          ]
        },
        {
          id: 'user-management', label: 'User Management', icon: 'group',
          links: [
            { label: 'All Users',            icon: 'people',                desc: 'View and manage all user accounts in the system.'       },
            { label: 'Add User',             icon: 'person_add',            desc: 'Onboard a new team member or administrator.'            },
            { label: 'Roles & Permissions',  icon: 'admin_panel_settings',  desc: 'Configure role-based access control policies.'          },
            { label: 'Activity Logs',        icon: 'timeline',              desc: 'Track user actions, logins, and session history.'       },
          ]
        },
        {
          id: 'report-management', label: 'Report Management', icon: 'bar_chart',
          links: [
            { label: 'Asset Reports',    icon: 'description',  desc: 'Generate and export asset inventory status reports.'    },
            { label: 'User Reports',     icon: 'summarize',    desc: 'Summarise user activity and access statistics.'         },
            { label: 'Audit Logs',       icon: 'fact_check',   desc: 'Compliance and change-tracking audit records.'          },
            { label: 'Scheduled Reports',icon: 'schedule',     desc: 'Automate recurring report generation and delivery.'     },
          ]
        }
      ]
    },
    {
      id: 'account', label: 'Account', icon: 'manage_accounts', groupLabel: 'Account Settings',
      sections: [
        {
          id: 'security', label: 'Security', icon: 'shield',
          links: [
            { label: '2FA Settings',    icon: 'phonelink_lock',  desc: 'Enable and configure two-factor authentication.'   },
            { label: 'Login History',   icon: 'history',         desc: 'Review recent sign-in sessions and locations.'      },
            { label: 'Active Sessions', icon: 'devices',         desc: 'View and revoke active device sessions.'            },
          ]
        },
        {
          id: 'billing', label: 'Billing', icon: 'receipt',
          links: [
            { label: 'Invoices',         icon: 'receipt_long',  desc: 'Download and review past billing invoices.'         },
            { label: 'Payment Methods',  icon: 'credit_card',   desc: 'Add or update stored payment details.'              },
            { label: 'Billing History',  icon: 'paid',          desc: 'Full transaction and payment history log.'          },
          ]
        },
        {
          id: 'preferences', label: 'Preferences', icon: 'tune',
          links: [
            { label: 'Notifications',  icon: 'notifications',  desc: 'Configure alert and notification preferences.'      },
            { label: 'Privacy',        icon: 'lock',           desc: 'Manage data sharing and privacy settings.'          },
            { label: 'Display',        icon: 'palette',        desc: 'Customise theme, layout, and display options.'      },
          ]
        }
      ]
    },
    {
      id: 'auth', label: 'Authentication', icon: 'lock_person', groupLabel: 'Auth Pages',
      sections: [
        {
          id: 'login', label: 'Login', icon: 'login',
          links: [
            { label: 'Sign In',        icon: 'login',     desc: 'Standard email and password login page.'           },
            { label: 'Sign In — 2FA',  icon: 'security',  desc: 'Two-factor authentication challenge flow.'         },
          ]
        },
        {
          id: 'register', label: 'Register', icon: 'person_add',
          links: [
            { label: 'Sign Up',      icon: 'person_add',        desc: 'New user self-registration form.'                  },
            { label: 'Email Verify', icon: 'mark_email_read',   desc: 'Email address confirmation step.'                  },
          ]
        },
        {
          id: 'recovery', label: 'Recovery', icon: 'lock_reset',
          links: [
            { label: 'Forgot Password',  icon: 'help_outline',  desc: 'Initiate the password reset flow.'                },
            { label: 'Reset Password',   icon: 'lock_reset',    desc: 'Set a new password after identity verification.'  },
          ]
        }
      ]
    },
    {
      id: 'utilities', label: 'Utilities', icon: 'build_circle', groupLabel: 'Utility Pages',
      sections: [
        {
          id: 'errors', label: 'Error Pages', icon: 'error',
          links: [
            { label: '404 Not Found',    icon: 'search_off',  desc: 'Page not found error screen.'                     },
            { label: '500 Server Error', icon: 'error',       desc: 'Internal server error fallback page.'              },
            { label: 'Maintenance',      icon: 'build',       desc: 'Under maintenance placeholder screen.'             },
          ]
        },
        {
          id: 'misc', label: 'Misc Pages', icon: 'more_horiz',
          links: [
            { label: 'Coming Soon',         icon: 'schedule',  desc: 'Product launch countdown page.'                  },
            { label: 'Terms & Conditions',  icon: 'gavel',     desc: 'Legal terms of service agreement page.'          },
          ]
        }
      ]
    },
    {
      id: 'widgets', label: 'Widgets', icon: 'widgets', groupLabel: 'UI Widgets',
      sections: [
        {
          id: 'charts', label: 'Charts', icon: 'show_chart',
          links: [
            { label: 'Line Charts',  icon: 'show_chart',  desc: 'Time-series and trend line visualisations.'          },
            { label: 'Bar Charts',   icon: 'bar_chart',   desc: 'Comparative bar and stacked column charts.'          },
            { label: 'Pie & Donut',  icon: 'pie_chart',   desc: 'Proportional segment and ring diagrams.'             },
          ]
        },
        {
          id: 'ui-elements', label: 'UI Elements', icon: 'layers',
          links: [
            { label: 'Alerts',   icon: 'warning',                 desc: 'Contextual alert and banner messages.'          },
            { label: 'Modals',   icon: 'open_in_new',             desc: 'Dialog overlays and confirmation panels.'       },
            { label: 'Toasts',   icon: 'notifications_active',    desc: 'Lightweight non-blocking toast notifications.'  },
          ]
        }
      ]
    }
  ];

  /* ── Derived state ───────────────────────────────────────── */
  activeTab = computed(() =>
    this.megaTabs.find(t => t.id === this.activeMegaTab()) ?? this.megaTabs[0]
  );

  activeSection = computed(() => {
    const tab = this.activeTab();
    return tab.sections.find(s => s.id === this.activeMegaSection()) ?? tab.sections[0];
  });

  /* ── Event handlers ──────────────────────────────────────── */
  toggleNotif(e: Event)    { e.stopPropagation(); this.notifOpen.update(v => !v);    this.settingsOpen.set(false); this.profileOpen.set(false); }
  toggleSettings(e: Event) { e.stopPropagation(); this.settingsOpen.update(v => !v); this.notifOpen.set(false);   this.profileOpen.set(false); }
  toggleProfile(e: Event)  { e.stopPropagation(); this.profileOpen.update(v => !v);  this.notifOpen.set(false);   this.settingsOpen.set(false); }
  stopProp(e: Event)       { e.stopPropagation(); }

  setMegaTab(tabId: string) {
    this.activeMegaTab.set(tabId);
    const tab = this.megaTabs.find(t => t.id === tabId);
    if (tab?.sections.length) this.activeMegaSection.set(tab.sections[0].id);
  }

  setMegaSection(sectionId: string) { this.activeMegaSection.set(sectionId); }

  @HostListener('document:click')
  closeAll() {
    this.notifOpen.set(false);
    this.settingsOpen.set(false);
    this.profileOpen.set(false);
    this.megaOpen.set(false);
  }
}
