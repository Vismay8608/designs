import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Department } from './department.model';

/**
 * Thin HTTP wrapper — the ONLY department-specific service. Everything else
 * (validation, toasts, permissions, modal, translation) is inherited.
 */
@Injectable({ providedIn: 'root' })
export class DepartmentApiService {
  private base = '/api/departments';
  constructor(private http: HttpClient) {}

  list(params: any): Observable<{ data: Department[]; total: number }> {
    return this.http.get<{ data: Department[]; total: number }>(this.base, { params });
  }
  create(payload: Partial<Department>): Observable<Department> {
    return this.http.post<Department>(this.base, payload);
  }
  update(id: number, payload: Partial<Department>): Observable<Department> {
    return this.http.put<Department>(`${this.base}/${id}`, payload);
  }
  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.base}/${id}`);
  }
}
