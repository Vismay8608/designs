export interface Department {
  id: number;
  name: string;
  code: string;
  status: 'DRAFT' | 'PENDING_REVIEW' | 'APPROVED' | 'REJECTED';
}
