import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { BaseCrudComponent } from '../../core/base/base-crud.component';
import { ValidationService } from '../../core/services/validation.service';
import { DepartmentApiService } from './department-api.service';
import { Department } from './department.model';

/**
 * DepartmentCreateComponent
 * ==========================
 * DEMO 1 of 2 — full CREATE/EDIT page built on BaseCrudComponent.
 *
 * WHAT THIS COMPONENT DOES NOT NEED TO DO (handled by the base class):
 *   - toast success/error messages
 *   - disabling the submit button during the request (replay-attack guard)
 *   - mapping server validation errors onto form fields
 *   - "please fill required fields" validation message
 *   - reload-after-save
 *
 * WHAT THIS COMPONENT DOES:
 *   - defines the form shape (buildForm)
 *   - wires the 3 HTTP calls (getListRequest/getCreateRequest/getUpdateRequest — list
 *     isn't used on a pure create page but is required by the abstract contract;
 *     in this demo the create page is embedded inside the search page's modal,
 *     so getListRequest just delegates to the same api.list())
 *   - customises the success message text (Tier 1)
 */
@Component({
  selector: 'app-department-create',
  templateUrl: './department-create.component.html',
})
export class DepartmentCreateComponent extends BaseCrudComponent<Department, number> {

  // ---- REQUIRED: entityName drives default translation keys like
  // 'department.create_success', 'department.update_success' ----
  protected entityName = 'department';

  private fb = inject(FormBuilder);
  private api = inject(DepartmentApiService);

  // ---- TIER 1 CUSTOMISATION ----
  // Your exact requirement: default is "Department created successfully",
  // override to "Department is created successfully and sent for review".
  // This is a ONE-LINE change — onSubmit(), the guard, validation, and
  // server-error handling are untouched.
  protected override messages = {
    createSuccess: this.t('department.create_success_review'),
  };

  // ---- REQUIRED HOOKS ----

  /**
   * CLIENT-SIDE validation lives here. Server-side validation needs zero
   * code from you — BaseCrudComponent.onSubmit() already calls
   * this.core.applyServerErrors(this.form, err) automatically on failure,
   * which populates control.errors.serverError, picked up by
   * <app-field-error> in the template.
   */
  protected buildForm(): FormGroup {
    return this.fb.group({
      name: ['', [Validators.required, ValidationService.noWhitespace]],
      code: ['', [Validators.required, Validators.maxLength(10), ValidationService.alphaNumericCode]],
    });
  }

  protected mapToPayload(formValue: any) {
    return { name: formValue.name, code: formValue.code };
  }

  protected getListRequest(params: any): Observable<{ data: Department[]; total: number }> {
    return this.api.list(params);
  }
  protected getCreateRequest(payload: any): Observable<Department> {
    return this.api.create(payload);
  }
  protected getUpdateRequest(id: number, payload: any): Observable<Department> {
    return this.api.update(id, payload);
  }
  protected getDeleteRequest(id: number): Observable<void> {
    return this.api.delete(id);
  }
  protected getIdOf(item: Department): number {
    return item.id;
  }

  // ---- OPTIONAL TIER 2 HOOK ----
  // Only needed if the "sent for review" text should be CONDITIONAL on the
  // server response rather than always shown. Left commented to show the
  // alternative to the Tier 1 override above — use ONE or the OTHER, not both.
  //
  // protected override getSuccessMessage(action: 'create'|'update'|'delete', response: Department): string {
  //   if (action === 'create' && response.status === 'PENDING_REVIEW') {
  //     return this.t('department.create_success_review');
  //   }
  //   return super.getSuccessMessage(action, response);
  // }

  protected override afterCreateSuccess(response: Department): void {
    // e.g. analytics event, or navigate to the review queue
  }
}
