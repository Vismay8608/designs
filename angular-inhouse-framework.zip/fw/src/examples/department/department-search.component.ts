import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { BaseSearchComponent } from '../../core/base/base-search.component';
import { DepartmentApiService } from './department-api.service';
import { Department } from './department.model';

/**
 * DepartmentSearchComponent
 * ===========================
 * DEMO 2 of 2 — full SEARCH/LIST page built on BaseSearchComponent.
 *
 * Shows: filter form, results table, sortable columns, pagination,
 * permission-gated action links (view/edit/delete), a view popup, and a
 * delete confirmation — all through inherited sealed methods.
 */
@Component({
  selector: 'app-department-search',
  templateUrl: './department-search.component.html',
})
export class DepartmentSearchComponent extends BaseSearchComponent<Department, number> {

  protected entityName = 'department';

  private api = inject(DepartmentApiService);
  private router = inject(Router);
  private fbLocal = inject(FormBuilder);

  // ---- OPTIONAL: filter form shape. Default (if omitted) is an empty
  // FormGroup, meaning loadResults() just fetches everything. ----
  protected override buildSearchForm(): FormGroup {
    return this.fbLocal.group({
      name: [''],
      code: [''],
      status: [''],
    });
  }

  // ---- REQUIRED ----
  protected getSearchRequest(criteria: any): Observable<{ data: Department[]; total: number }> {
    return this.api.list(criteria);
  }
  protected getIdOf(item: Department): number {
    return item.id;
  }

  // ---- OPTIONAL: enables the delete action in the grid. If you omit this
  // method entirely, BaseSearchComponent detects it's missing and the
  // delete link/button (gated by *appHasPermission anyway) has nothing to
  // call — a console warning fires instead of a silent no-op bug. ----
  protected override getDeleteRequest(id: number): Observable<void> {
    return this.api.delete(id);
  }

  // ---- OPTIONAL: override default navigate-to-edit-page behaviour ----
  protected override navigateToEdit(item: Department): void {
    this.router.navigate(['/department/edit', item.id]);
  }
}
