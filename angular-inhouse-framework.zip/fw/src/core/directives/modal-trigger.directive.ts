import { Directive, HostListener, Input, TemplateRef, inject } from '@angular/core';
import { ModalService } from '../services/modal.service';

/**
 * appModalTrigger
 * ================
 * PURPOSE: standardises "click this element -> open this popup" so every
 * developer stops writing their own openViewModal()/showPopup()/openDialog()
 * method with a different name per page.
 *
 * USAGE:
 *   <button [appModalTrigger]="viewTpl">View</button>
 *   <ng-template #viewTpl>...popup content, e.g. department details...</ng-template>
 *
 * For popups tied to a specific row (view/edit), BaseCrudComponent's own
 * onView(item, tpl) / onEdit(item, tpl) already do this for you — use this
 * directive directly only for popups NOT tied to base-component lifecycle,
 * e.g. a generic "Help" or "Filters" popup.
 */
@Directive({ selector: '[appModalTrigger]', standalone: true })
export class ModalTriggerDirective {
  private modal = inject(ModalService);

  @Input('appModalTrigger') template!: TemplateRef<any>;
  @Input() modalConfig?: Record<string, any>;

  @HostListener('click')
  onClick(): void {
    this.modal.open(this.template, this.modalConfig);
  }
}
