import { Directive, EventEmitter, HostListener, Input, Output, inject } from '@angular/core';
import { ModalService } from '../services/modal.service';

/**
 * appConfirmClick
 * ================
 * PURPOSE: generic "confirm before doing X" — used for delete links, bulk
 * actions, or any destructive/irreversible action OUTSIDE the standard
 * onDelete() flow already built into BaseCrudComponent/BaseSearchComponent.
 * (Those two call ModalService.confirm() internally already — use THIS
 * directive only for custom confirm flows, e.g. "Deactivate user",
 * "Send for approval", "Cancel request".)
 *
 * USAGE:
 *   <button appConfirmClick
 *           confirmTitle="Deactivate user?"
 *           confirmMessage="This will revoke their access immediately."
 *           (confirmed)="deactivateUser(user)">
 *     Deactivate
 *   </button>
 */
@Directive({ selector: '[appConfirmClick]', standalone: true })
export class ConfirmClickDirective {
  private modal = inject(ModalService);

  @Input() confirmTitle = 'Are you sure?';
  @Input() confirmMessage = 'This action cannot be undone.';
  @Output() confirmed = new EventEmitter<void>();

  @HostListener('click', ['$event'])
  onClick(event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    this.modal.confirm({ title: this.confirmTitle, message: this.confirmMessage })
      .subscribe((ok) => { if (ok) this.confirmed.emit(); });
  }
}
