import { Directive, HostBinding, HostListener, Input } from '@angular/core';

/**
 * appSubmitGuard
 * ===============
 * PURPOSE: prevents the exact bug you described — a developer forgetting to
 * disable the submit button, causing duplicate records via double-click /
 * replay.
 *
 * USAGE (in your template — no component code needed, isSubmitting already
 * exists on every BaseCrudComponent):
 *
 *   <button [appSubmitGuard]="isSubmitting" (click)="onSubmit()">Save</button>
 *
 * It (a) sets [disabled] automatically while isSubmitting is true, and
 * (b) also blocks the click event itself as a second layer of defence, in
 * case [disabled] styling is overridden by page-specific CSS.
 */
@Directive({ selector: '[appSubmitGuard]', standalone: true })
export class SubmitGuardDirective {
  @Input('appSubmitGuard') isSubmitting = false;

  @HostBinding('disabled')
  get disabled(): boolean { return this.isSubmitting; }

  @HostListener('click', ['$event'])
  onClick(event: Event): void {
    if (this.isSubmitting) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }
}
