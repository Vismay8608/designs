import { Directive, Input, TemplateRef, ViewContainerRef, OnInit, inject } from '@angular/core';
import { PermissionService } from '../services/permission.service';

/**
 * *appHasPermission
 * ===================
 * STRUCTURAL directive (same family as *ngIf) — completely REMOVES the
 * element from the DOM (not just hides it with CSS) if the user lacks the
 * permission. This is the standard way to show/hide edit links, delete
 * buttons, action menu items, entire toolbar sections, etc.
 *
 * USAGE:
 *   <a *appHasPermission="'department.edit'" (click)="onEdit(item)">Edit</a>
 *   <button *appHasPermission="'department.delete'" (click)="onDelete(item)">Delete</button>
 *
 * Multiple permissions (ANY of them grants access):
 *   <div *appHasPermission="['department.edit','department.view']">...</div>
 */
@Directive({ selector: '[appHasPermission]', standalone: true })
export class HasPermissionDirective implements OnInit {
  private templateRef = inject(TemplateRef<any>);
  private viewContainer = inject(ViewContainerRef);
  private permissionService = inject(PermissionService);

  @Input('appHasPermission') permissionKey: string | string[] = '';

  ngOnInit(): void {
    const keys = Array.isArray(this.permissionKey) ? this.permissionKey : [this.permissionKey];
    const allowed = this.permissionService.hasAny(keys);
    this.viewContainer.clear();
    if (allowed) this.viewContainer.createEmbeddedView(this.templateRef);
  }
}
