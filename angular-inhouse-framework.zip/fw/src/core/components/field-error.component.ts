import { Component, Input } from '@angular/core';
import { AbstractControl } from '@angular/forms';

/**
 * <app-field-error>
 * ===================
 * NOTE ON WHY THIS IS A COMPONENT, NOT A DIRECTIVE:
 * A structural/attribute directive can hide or transform an existing
 * element, but it cannot inject NEW markup (an error message span) into the
 * DOM cleanly without an ng-template — so for anything that needs to render
 * content, a small component is the correct tool. Directives are for
 * BEHAVIOUR on existing elements (appSubmitGuard, appHasPermission,
 * appModalTrigger above); components are for behaviour + markup.
 *
 * Displays BOTH client-side validator errors (required, email, minlength...)
 * AND server-side errors (the `serverError` key set by
 * ValidationService.applyServerErrors()) with the same visual style — the
 * end user cannot tell the difference, which is exactly the point: one
 * consistent validation UX everywhere.
 *
 * USAGE:
 *   <input formControlName="email" />
 *   <app-field-error [control]="form.get('email')" fieldLabel="Email"></app-field-error>
 */
@Component({
  selector: 'app-field-error',
  standalone: true,
  template: `
    <div class="field-error" *ngIf="control?.invalid && control?.touched">
      <span *ngIf="control?.errors?.['required']">{{ fieldLabel }} is required.</span>
      <span *ngIf="control?.errors?.['email']">Enter a valid email address.</span>
      <span *ngIf="control?.errors?.['minlength']">
        {{ fieldLabel }} must be at least {{ control?.errors?.['minlength']?.requiredLength }} characters.
      </span>
      <span *ngIf="control?.errors?.['maxlength']">
        {{ fieldLabel }} must be at most {{ control?.errors?.['maxlength']?.requiredLength }} characters.
      </span>
      <span *ngIf="control?.errors?.['whitespace']">{{ fieldLabel }} cannot be blank spaces.</span>
      <span *ngIf="control?.errors?.['alphaNumericCode']">{{ fieldLabel }} allows letters, numbers, _ and - only.</span>
      <!-- server-side error, injected by ValidationService.applyServerErrors() -->
      <span *ngIf="control?.errors?.['serverError']">{{ control?.errors?.['serverError'] }}</span>
    </div>
  `,
})
export class FieldErrorComponent {
  @Input() control: AbstractControl | null = null;
  @Input() fieldLabel = 'This field';
}
