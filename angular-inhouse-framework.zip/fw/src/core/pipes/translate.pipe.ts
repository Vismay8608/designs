import { Pipe, PipeTransform, inject } from '@angular/core';
import { TranslationService } from '../services/translation.service';

/**
 * appTranslate pipe
 * ===================
 * Template shorthand so devs don't inject TranslationService into every
 * component just to translate a label in HTML.
 *
 * USAGE:  {{ 'department.title' | appTranslate }}
 *         {{ 'department.welcome' | appTranslate:{ name: user.name } }}
 */
@Pipe({ name: 'appTranslate', standalone: true, pure: false })
export class TranslatePipe implements PipeTransform {
  private translate = inject(TranslationService);
  transform(key: string, params?: Record<string, any>): string {
    return this.translate.instant(key, params);
  }
}
