import { Pipe, PipeTransform } from '@angular/core';

export interface StatusBadge { label: string; cssClass: string; }

const STATUS_MAP: Record<string, StatusBadge> = {
  DRAFT:           { label: 'Draft',           cssClass: 'badge-secondary' },
  PENDING_REVIEW:  { label: 'Pending Review',  cssClass: 'badge-warning'   },
  APPROVED:        { label: 'Approved',        cssClass: 'badge-success'   },
  REJECTED:        { label: 'Rejected',        cssClass: 'badge-danger'    },
};

/**
 * appStatusBadge pipe
 * =====================
 * Standardises how status enums are rendered across every search/list page
 * — one lookup table instead of a *ngSwitch per component.
 *
 * USAGE:  <span class="badge" [ngClass]="(item.status | appStatusBadge).cssClass">
 *           {{ (item.status | appStatusBadge).label }}
 *         </span>
 */
@Pipe({ name: 'appStatusBadge', standalone: true })
export class StatusBadgePipe implements PipeTransform {
  transform(status: string): StatusBadge {
    return STATUS_MAP[status] ?? { label: status, cssClass: 'badge-secondary' };
  }
}
