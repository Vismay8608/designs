import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ToastService } from './services/toast.service';
import { ValidationService } from './services/validation.service';
import { TranslationService } from './services/translation.service';
import { PermissionService } from './services/permission.service';
import { ModalService } from './services/modal.service';
import { LoadingService } from './services/loading.service';

/**
 * CoreFacadeService
 * ------------------
 * The ONE thing every base component injects. Instead of a page component
 * importing 6+ services individually, BaseComponent injects this once and
 * exposes it as `this.core`. Every page then accesses:
 *
 *   this.core.toast.success('...')
 *   this.core.validation.markAllTouched(this.form)
 *   this.core.translate.instant('key')
 *   this.core.permission.has('department.edit')
 *   this.core.modal.open(tpl)
 *   this.core.loading.show()
 *
 * Most of the time you won't even call these directly — BaseCrudComponent /
 * BaseSearchComponent already call them for you inside sealed methods
 * (onSubmit, onDelete, loadList, etc). You reach into `this.core` yourself
 * only for page-specific logic in your override hooks.
 */
@Injectable({ providedIn: 'root' })
export class CoreFacadeService {
  constructor(
    public toast: ToastService,
    public validation: ValidationService,
    public translate: TranslationService,
    public permission: PermissionService,
    public modal: ModalService,
    public loading: LoadingService
  ) {}

  t(key: string, params?: Record<string, any>): string {
    return this.translate.instant(key, params);
  }

  applyServerErrors(form: FormGroup, error: any): void {
    this.validation.applyServerErrors(form, error);
  }

  extractErrorMessage(error: any): string {
    return this.validation.extractMessage(error);
  }
}
