import { Directive, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Observable, finalize, takeUntil } from 'rxjs';
import { BaseComponent } from './base.component';

/**
 * BaseSearchComponent<T, TId>
 * ============================
 * Use for LIST / SEARCH pages: a filter form + results table + row actions
 * (view / edit-navigate / delete). This is deliberately separate from
 * BaseCrudComponent because a search page's "form" is filter criteria, not
 * an entity being created — different validation rules, different submit
 * semantics (no double-submit guard needed, filters can be resubmitted freely).
 *
 * ── METHOD REFERENCE (full list) ──────────────────────────────────────────
 * SEALED:
 *   loadResults(criteria?)   - fetch page of results
 *   onSearch()               - validate filters (if configured), reset to page 1, reload
 *   onClearSearch()          - reset filter form, reload unfiltered
 *   onPageChange(page)       - change page, reload
 *   onSort(field)            - toggle sort direction on a column, reload
 *   onView(item, modalTpl)   - open read-only view popup
 *   onEdit(item)             - navigate to edit page (default) or open modal (override)
 *   onDelete(item)           - confirm + delete + reload (only if getDeleteRequest is implemented)
 *   openModal(tpl) / closeModal()
 *
 * REQUIRED overrides:
 *   entityName, getSearchRequest(), getIdOf()
 *
 * OPTIONAL overrides:
 *   buildSearchForm()   - default: empty FormGroup (no filters)
 *   getDeleteRequest()  - implement to enable the delete action; omit to hide it
 *   navigateToEdit()    - default: router.navigate(['/', entityName, 'edit', id])
 *   messages            - Tier 1 text overrides (same pattern as BaseCrudComponent)
 * ───────────────────────────────────────────────────────────────────────
 */
@Directive()
export abstract class BaseSearchComponent<T, TId = number> extends BaseComponent {

  protected abstract entityName: string;
  protected fb = new FormBuilder(); // safe to instantiate directly, FormBuilder has no dependencies

  searchForm!: FormGroup;
  results: T[] = [];
  totalRecords = 0;
  page = 1;
  pageSize = 10;
  sortField: string | null = null;
  sortDir: 'asc' | 'desc' = 'asc';
  /** set by onView() so the view-modal template can read `selectedItem` */
  selectedItem: T | null = null;

  private modalRef: any = null;

  protected messages: Partial<{ deleteSuccess: string; deleteConfirmTitle: string; deleteConfirmMessage: string }> = {};

  // ---- REQUIRED hooks ----
  protected abstract getSearchRequest(criteria: any): Observable<{ data: T[]; total: number }>;
  protected abstract getIdOf(item: T): TId;

  protected override onInit(): void {
    this.searchForm = this.buildSearchForm();
    this.loadResults();
  }

  loadResults(criteria: any = this.searchForm?.value ?? {}): void {
    this.isLoading = true;
    this.getSearchRequest({
      ...criteria,
      page: this.page,
      pageSize: this.pageSize,
      sortField: this.sortField,
      sortDir: this.sortDir,
    })
      .pipe(finalize(() => (this.isLoading = false)), takeUntil(this.destroy$))
      .subscribe({
        next: (res) => { this.results = res.data; this.totalRecords = res.total; },
        error: (err) => this.core.toast.error(this.core.extractErrorMessage(err)),
      });
  }

  onSearch(): void { this.page = 1; this.loadResults(); }
  onClearSearch(): void { this.searchForm.reset(); this.page = 1; this.loadResults({}); }
  onPageChange(page: number): void { this.page = page; this.loadResults(); }

  onSort(field: string): void {
    this.sortDir = this.sortField === field && this.sortDir === 'asc' ? 'desc' : 'asc';
    this.sortField = field;
    this.loadResults();
  }

  onView(item: T, modalTpl: TemplateRef<any>): void { this.selectedItem = item; this.openModal(modalTpl); }

  /** default behaviour: navigate to a dedicated edit page. Override for modal-based editing. */
  onEdit(item: T): void { this.navigateToEdit(item); }

  onDelete(item: T): void {
    const del = this.getDeleteRequest?.(this.getIdOf(item));
    if (!del) {
      console.warn(`[BaseSearchComponent] getDeleteRequest() not implemented for ${this.entityName} — delete action disabled.`);
      return;
    }
    this.core.modal.confirm({
      title: this.messages.deleteConfirmTitle ?? this.t('common.delete_confirm_title'),
      message: this.messages.deleteConfirmMessage ?? this.t('common.delete_confirm_message', { entity: this.entityName }),
    }).subscribe((confirmed) => {
      if (!confirmed) return;
      del.pipe(takeUntil(this.destroy$)).subscribe({
        next: () => {
          this.core.toast.success(this.messages.deleteSuccess ?? this.t(`${this.entityName}.delete_success`));
          this.loadResults();
        },
        error: (err) => this.core.toast.error(this.core.extractErrorMessage(err)),
      });
    });
  }

  openModal(tpl: TemplateRef<any>): void { this.modalRef = this.core.modal.open(tpl); }
  closeModal(): void { this.modalRef?.close(); this.modalRef = null; }

  // ---- OPTIONAL hooks ----
  protected buildSearchForm(): FormGroup { return this.fb.group({}); }
  /** implement to enable delete from the results grid; leave unimplemented to hide the delete action entirely */
  protected getDeleteRequest?(id: TId): Observable<void>;
  protected navigateToEdit(item: T): void {
    // inject Router in the concrete component if you need real navigation;
    // kept generic here since BaseComponent has no router dependency by default
    console.log(`[BaseSearchComponent] navigate to /${this.entityName}/edit/${this.getIdOf(item)}`);
  }
}
