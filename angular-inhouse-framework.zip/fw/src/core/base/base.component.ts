import { Directive, OnDestroy, OnInit, inject } from '@angular/core';
import { Subject } from 'rxjs';
import { CoreFacadeService } from '../core-facade.service';

/**
 * BaseComponent
 * =============
 * ROOT of the hierarchy. BaseCrudComponent and BaseSearchComponent both
 * extend this. If you ever build BaseDashboardComponent, it extends this too.
 *
 * ── HOW A DEVELOPER ACCESSES BASE COMPONENT METHODS ──────────────────────
 * Because your page component `extends BaseCrudComponent<Department>` (or
 * BaseSearchComponent), everything below is automatically available on
 * `this` inside your component — no injection, no imports needed:
 *
 *   this.core         -> CoreFacadeService (toast, validation, translate, permission, modal, loading)
 *   this.destroy$      -> Subject for takeUntil() unsubscription
 *   this.t('key')       -> translation shorthand
 *   this.can('perm.key')-> permission shorthand
 *   this.isLoading      -> boolean, auto-managed
 *
 * You NEVER call `new BaseComponent()` and you never inject it manually —
 * it becomes part of `this` purely through `extends`.
 * ───────────────────────────────────────────────────────────────────────
 */
@Directive() // marker so the abstract class gets its own DI context; not used as a real directive
export abstract class BaseComponent implements OnInit, OnDestroy {
  protected core = inject(CoreFacadeService);
  protected destroy$ = new Subject<void>();
  isLoading = false;

  ngOnInit(): void { this.onInit(); }
  ngOnDestroy(): void { this.destroy$.next(); this.destroy$.complete(); this.onDestroy(); }

  protected t(key: string, params?: Record<string, any>): string {
    return this.core.t(key, params);
  }

  /** used directly in templates too: *ngIf="can('department.edit')" */
  can(permissionKey: string): boolean {
    return this.core.permission.has(permissionKey);
  }

  protected withLoading<T>(fn: () => Promise<T> | void): void {
    this.isLoading = true;
    Promise.resolve(fn()).finally(() => (this.isLoading = false));
  }

  /** OPTIONAL hook — override only if you need extra init logic */
  protected onInit(): void {}
  /** OPTIONAL hook — override only if you need extra cleanup logic */
  protected onDestroy(): void {}
}
