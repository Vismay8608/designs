import { Directive, TemplateRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Observable, finalize, takeUntil } from 'rxjs';
import { BaseComponent } from './base.component';

export type CrudAction = 'create' | 'update' | 'delete';

export interface CrudMessages {
  createSuccess: string;
  updateSuccess: string;
  deleteSuccess: string;
  deleteConfirmTitle: string;
  deleteConfirmMessage: string;
  validationRequired: string;
}

/**
 * BaseCrudComponent<T, TId>
 * =========================
 * Use for CREATE / EDIT pages (a form that submits to an API).
 * For LIST / SEARCH pages with no submit form, use BaseSearchComponent instead.
 *
 * ── METHOD REFERENCE (full list) ──────────────────────────────────────────
 * SEALED (call these from your template; do not rename or duplicate them):
 *   loadList(criteria?)      - fetch list data
 *   onSearch(criteria)       - reset to page 1 and reload with filters
 *   onClearSearch()          - reload without filters
 *   onAdd(modalTpl?)         - reset form, open create modal
 *   onEdit(item, modalTpl?)  - patch form with item, open edit modal
 *   onView(item, modalTpl)   - open read-only view modal
 *   onDelete(item)           - confirm + delete + reload
 *   onSubmit()               - validate, guard double-submit, create/update, toast, reload
 *   onReset()                - reset form to default values
 *   openModal(tpl) / closeModal()
 *
 * REQUIRED overrides (abstract, no default — component won't compile without these):
 *   entityName, buildForm(), mapToPayload(), getListRequest(), getCreateRequest(),
 *   getUpdateRequest(), getDeleteRequest(), getIdOf()
 *
 * OPTIONAL overrides (Tier 1/2 customisation — see README):
 *   messages (Tier 1: static text)
 *   getSuccessMessage(), getErrorMessage(), beforeSubmit(), mapItemToForm(),
 *   getDefaultFormValue(), afterCreateSuccess(), afterUpdateSuccess(),
 *   afterDeleteSuccess(), afterSubmitError(), afterReset()
 * ───────────────────────────────────────────────────────────────────────
 */
@Directive()
export abstract class BaseCrudComponent<T, TId = number> extends BaseComponent {

  protected abstract entityName: string;
  form!: FormGroup;

  items: T[] = [];
  selectedItem: T | null = null;
  isEditMode = false;
  isSubmitting = false; // bound to appSubmitGuard directive in templates
  totalRecords = 0;
  page = 1;
  pageSize = 10;
  private modalRef: any = null;

  protected messages: Partial<CrudMessages> = {};

  private get defaultMessages(): CrudMessages {
    return {
      createSuccess: this.t(`${this.entityName}.create_success`),
      updateSuccess: this.t(`${this.entityName}.update_success`),
      deleteSuccess: this.t(`${this.entityName}.delete_success`),
      deleteConfirmTitle: this.t('common.delete_confirm_title'),
      deleteConfirmMessage: this.t('common.delete_confirm_message', { entity: this.entityName }),
      validationRequired: this.t('common.validation_at_least_one_field'),
    };
  }

  private get resolvedMessages(): CrudMessages {
    return { ...this.defaultMessages, ...this.messages };
  }

  // ---- REQUIRED hooks ----
  protected abstract buildForm(): FormGroup;
  protected abstract mapToPayload(formValue: any): any;
  protected abstract getListRequest(params: any): Observable<{ data: T[]; total: number }>;
  protected abstract getCreateRequest(payload: any): Observable<T>;
  protected abstract getUpdateRequest(id: TId, payload: any): Observable<T>;
  protected abstract getDeleteRequest(id: TId): Observable<void>;
  protected abstract getIdOf(item: T): TId;

  protected override onInit(): void {
    this.form = this.buildForm();
    this.loadList();
  }

  loadList(searchCriteria: any = {}): void {
    this.isLoading = true;
    this.getListRequest({ page: this.page, pageSize: this.pageSize, ...searchCriteria })
      .pipe(finalize(() => (this.isLoading = false)), takeUntil(this.destroy$))
      .subscribe({
        next: (res) => { this.items = res.data; this.totalRecords = res.total; },
        error: (err) => this.core.toast.error(this.core.extractErrorMessage(err)),
      });
  }

  onSearch(criteria: any): void { this.page = 1; this.loadList(criteria); }
  onClearSearch(): void { this.page = 1; this.loadList(); }

  onAdd(modalTpl?: TemplateRef<any>): void {
    this.isEditMode = false;
    this.selectedItem = null;
    this.form.reset(this.getDefaultFormValue());
    if (modalTpl) this.openModal(modalTpl);
  }

  onEdit(item: T, modalTpl?: TemplateRef<any>): void {
    this.isEditMode = true;
    this.selectedItem = item;
    this.form.patchValue(this.mapItemToForm(item));
    if (modalTpl) this.openModal(modalTpl);
  }

  onView(item: T, modalTpl: TemplateRef<any>): void {
    this.selectedItem = item;
    this.openModal(modalTpl);
  }

  onDelete(item: T): void {
    const m = this.resolvedMessages;
    this.core.modal.confirm({ title: m.deleteConfirmTitle, message: m.deleteConfirmMessage })
      .subscribe((confirmed: boolean) => {
        if (!confirmed) return;
        this.getDeleteRequest(this.getIdOf(item)).pipe(takeUntil(this.destroy$)).subscribe({
          next: () => {
            this.core.toast.success(m.deleteSuccess);
            this.afterDeleteSuccess(item);
            this.loadList();
          },
          error: (err) => this.core.toast.error(this.core.extractErrorMessage(err)),
        });
      });
  }

  /** Sealed. Built-in replay-attack guard via isSubmitting — cannot be bypassed by forgetting a [disabled] binding. */
  onSubmit(): void {
    if (this.isSubmitting) return;

    if (this.form.invalid) {
      this.core.validation.markAllTouched(this.form);
      this.core.toast.warn(this.resolvedMessages.validationRequired);
      return;
    }

    const rawPayload = this.mapToPayload(this.form.value);
    const payload = this.beforeSubmit(rawPayload);
    this.isSubmitting = true;

    const request$ = this.isEditMode
      ? this.getUpdateRequest(this.getIdOf(this.selectedItem as T), payload)
      : this.getCreateRequest(payload);

    request$.pipe(finalize(() => (this.isSubmitting = false)), takeUntil(this.destroy$)).subscribe({
      next: (response) => {
        const action: CrudAction = this.isEditMode ? 'update' : 'create';
        this.core.toast.success(this.getSuccessMessage(action, response));
        this.isEditMode ? this.afterUpdateSuccess(response) : this.afterCreateSuccess(response);
        this.closeModal();
        this.loadList();
      },
      error: (err) => {
        this.core.applyServerErrors(this.form, err); // server-side validation mapped to fields
        this.core.toast.error(this.getErrorMessage(err));
        this.afterSubmitError(err);
      },
    });
  }

  onReset(): void { this.form.reset(this.getDefaultFormValue()); this.afterReset(); }
  openModal(tpl: TemplateRef<any>): void { this.modalRef = this.core.modal.open(tpl); }
  closeModal(): void { this.modalRef?.close(); this.modalRef = null; }

  // ---- OPTIONAL hooks (Tier 2) ----
  protected getSuccessMessage(action: CrudAction, response: T): string {
    const m = this.resolvedMessages;
    return action === 'create' ? m.createSuccess : m.updateSuccess;
  }
  protected getErrorMessage(err: any): string { return this.core.extractErrorMessage(err); }
  protected beforeSubmit(payload: any): any { return payload; }
  protected mapItemToForm(item: T): any { return item; }
  protected getDefaultFormValue(): any { return {}; }
  protected afterCreateSuccess(response: T): void {}
  protected afterUpdateSuccess(response: T): void {}
  protected afterDeleteSuccess(item: T): void {}
  protected afterSubmitError(err: any): void {}
  protected afterReset(): void {}
}
