import { Injectable, TemplateRef, Type } from '@angular/core';
import { Observable, Subject } from 'rxjs';

export interface ModalRef {
  close: (result?: any) => void;
}

export interface ConfirmOptions {
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
}

/**
 * ModalService
 * ------------
 * ONE way to open popups across the app — view popups, edit popups, and
 * confirm dialogs (used for delete confirmations everywhere).
 *
 * NOTE: this is a thin facade. Wire `open()`/`confirm()` to whatever modal
 * library the org uses (ng-bootstrap NgbModal, Angular CDK Dialog, PrimeNG,
 * etc.) — pages never talk to that library directly, only to this service.
 */
@Injectable({ providedIn: 'root' })
export class ModalService {

  open(content: TemplateRef<any> | Type<any>, config?: Record<string, any>): ModalRef {
    // Real implementation delegates to your modal library, e.g.:
    // const ref = this.ngbModal.open(content, config);
    // return { close: (result) => ref.close(result) };
    console.log('[ModalService] open()', content, config);
    return { close: () => console.log('[ModalService] close()') };
  }

  confirm(options: ConfirmOptions): Observable<boolean> {
    const subject = new Subject<boolean>();
    // Real implementation opens a confirm dialog component and resolves
    // the subject with true/false based on the button clicked.
    console.log('[ModalService] confirm()', options);
    return subject.asObservable();
  }
}
