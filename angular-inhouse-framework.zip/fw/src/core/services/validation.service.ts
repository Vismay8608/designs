import { Injectable } from '@angular/core';
import { AbstractControl, FormGroup, ValidatorFn, ValidationErrors } from '@angular/forms';

/**
 * ValidationService
 * ------------------
 * Handles BOTH client-side and server-side validation the same way on every
 * page, so devs stop writing form.get('x').hasError('required') differently
 * everywhere.
 *
 * CLIENT-SIDE validation: use the custom validators below in buildForm().
 * SERVER-SIDE validation: call applyServerErrors(form, httpError) inside the
 * base component's onSubmit() error handler — this is already wired
 * automatically in BaseCrudComponent, you never call it yourself.
 */
@Injectable({ providedIn: 'root' })
export class ValidationService {

  /** touches every control so *ngIf="control.invalid && control.touched" errors show immediately */
  markAllTouched(form: FormGroup): void {
    Object.values(form.controls).forEach(c => {
      c.markAsTouched();
      c.markAsDirty();
      if (c instanceof FormGroup) this.markAllTouched(c);
    });
  }

  /**
   * Maps a standard backend error shape into Angular form control errors,
   * so <app-field-error> can display them exactly like client errors.
   * Expected server shape:
   *   { errors: [ { field: 'email', message: 'Email already exists' } ] }
   */
  applyServerErrors(form: FormGroup, httpError: any): void {
    const errors = httpError?.error?.errors as Array<{ field: string; message: string }> | undefined;
    if (!errors) return;
    errors.forEach(e => {
      const control = form.get(e.field);
      if (control) {
        control.setErrors({ ...(control.errors || {}), serverError: e.message });
        control.markAsTouched();
      }
    });
  }

  extractMessage(httpError: any): string {
    return httpError?.error?.message || 'Something went wrong. Please try again.';
  }

  // ---------------------------------------------------------------------
  // CLIENT-SIDE custom validators — reused across every form in the org
  // ---------------------------------------------------------------------

  /** "please enter at least one field" — validator on the FormGroup, not a single control */
  static atLeastOneRequired(fields: string[]): ValidatorFn {
    return (group: AbstractControl): ValidationErrors | null => {
      const filled = fields.some(f => !!(group as FormGroup).get(f)?.value);
      return filled ? null : { atLeastOneRequired: true };
    };
  }

  static noWhitespace(control: AbstractControl): ValidationErrors | null {
    const isWhitespace = (control.value || '').trim().length === 0 && (control.value || '').length > 0;
    return isWhitespace ? { whitespace: true } : null;
  }

  static alphaNumericCode(control: AbstractControl): ValidationErrors | null {
    const valid = /^[A-Za-z0-9_-]*$/.test(control.value || '');
    return valid ? null : { alphaNumericCode: true };
  }
}
