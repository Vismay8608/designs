import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

/**
 * LoadingService
 * ---------------
 * Tracks in-flight request count globally so a single top-level loading
 * bar / spinner can react, in addition to each component's local isLoading flag.
 */
@Injectable({ providedIn: 'root' })
export class LoadingService {
  private counter = 0;
  private _isLoading$ = new BehaviorSubject<boolean>(false);
  isLoading$ = this._isLoading$.asObservable();

  show(): void {
    this.counter++;
    this._isLoading$.next(true);
  }

  hide(): void {
    this.counter = Math.max(0, this.counter - 1);
    this._isLoading$.next(this.counter > 0);
  }
}
