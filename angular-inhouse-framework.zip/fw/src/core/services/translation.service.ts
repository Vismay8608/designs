import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core'; // assumes ngx-translate is the org standard

/**
 * TranslationService
 * -------------------
 * Thin wrapper over ngx-translate so the rest of the framework (and every
 * page) depends on OUR interface, not directly on the 3rd-party library.
 * If the org ever swaps i18n libraries, only this file changes.
 */
@Injectable({ providedIn: 'root' })
export class TranslationService {
  constructor(private translate: TranslateService) {}

  instant(key: string, params?: Record<string, any>): string {
    return this.translate.instant(key, params);
  }

  get(key: string, params?: Record<string, any>) {
    return this.translate.get(key, params);
  }

  use(lang: string): void {
    this.translate.use(lang);
  }

  currentLang(): string {
    return this.translate.currentLang;
  }
}
