import { Injectable } from '@angular/core';

/**
 * PermissionService
 * -------------------
 * Single source of truth for "can this user do X". Backed by whatever your
 * auth/session store is (replace loadPermissions() with your real call).
 *
 * Consumed by:
 *  - BaseComponent.can() shorthand
 *  - *appHasPermission structural directive (show/hide buttons, links, menu items)
 */
@Injectable({ providedIn: 'root' })
export class PermissionService {
  private permissions = new Set<string>();

  /** call once after login / app bootstrap */
  loadPermissions(keys: string[]): void {
    this.permissions = new Set(keys);
  }

  has(key: string): boolean {
    return this.permissions.has(key);
  }

  hasAny(keys: string[]): boolean {
    return keys.some(k => this.permissions.has(k));
  }

  hasAll(keys: string[]): boolean {
    return keys.every(k => this.permissions.has(k));
  }
}
