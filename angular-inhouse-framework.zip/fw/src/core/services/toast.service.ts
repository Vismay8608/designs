import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface ToastMessage {
  id: number;
  type: 'success' | 'error' | 'warn' | 'info';
  text: string;
}

/**
 * ToastService
 * ------------
 * Every page shows success/error/warning messages through THIS service only.
 * A single <app-toast-container> component (not included here — just a
 * subscriber to `messages$`) renders whatever is pushed here.
 *
 * Why centralised: before this framework, some devs used window.alert(),
 * some used a 3rd-party toastr directly, some rolled their own <div>.
 * Now there is exactly one way.
 */
@Injectable({ providedIn: 'root' })
export class ToastService {
  private counter = 0;
  private _messages$ = new BehaviorSubject<ToastMessage[]>([]);
  /** subscribe to this in your root ToastContainerComponent */
  messages$ = this._messages$.asObservable();

  success(text: string): void { this.push('success', text); }
  error(text: string): void { this.push('error', text); }
  warn(text: string): void { this.push('warn', text); }
  info(text: string): void { this.push('info', text); }

  dismiss(id: number): void {
    this._messages$.next(this._messages$.value.filter(m => m.id !== id));
  }

  private push(type: ToastMessage['type'], text: string): void {
    const msg: ToastMessage = { id: ++this.counter, type, text };
    this._messages$.next([...this._messages$.value, msg]);
    // auto-dismiss after 5s
    setTimeout(() => this.dismiss(msg.id), 5000);
  }
}
