# In-House Angular Framework — Reference Guide

Everything in this package solves ONE problem: **100 developers, one set of
method names, one set of behaviors.** Read this top-to-bottom once; after
that it's a lookup table.

---

## 1. How a developer accesses base component methods

You never inject the base classes. You `extends` them, and everything
becomes part of `this`:

```typescript
export class DepartmentCreateComponent extends BaseCrudComponent<Department, number> {
  // this.core, this.form, this.onSubmit(), this.t(), this.can() — all inherited
}
```

In the **template**, sealed methods are called directly (`(click)="onSubmit()"`,
`(click)="onDelete(item)"`) exactly as if they were defined locally — Angular
doesn't distinguish inherited vs. own methods in a template binding.

---

## 2. Full method reference — `BaseCrudComponent<T, TId>`

Use for **create/edit** pages (a form that submits to an API).

| Method | Type | Description |
|---|---|---|
| `loadList(criteria?)` | Sealed | Fetch list data (used when a create page also lists prior entries, e.g. inline table above a form) |
| `onSearch(criteria)` | Sealed | Reset to page 1, reload with filters |
| `onClearSearch()` | Sealed | Reload without filters |
| `onAdd(modalTpl?)` | Sealed | Reset form to defaults, open create modal |
| `onEdit(item, modalTpl?)` | Sealed | Patch form with item's values, open edit modal |
| `onView(item, modalTpl)` | Sealed | Open read-only view popup |
| `onDelete(item)` | Sealed | Confirm dialog → delete → toast → reload |
| `onSubmit()` | Sealed | Validate → guard double-submit → create/update → toast → reload |
| `onReset()` | Sealed | Reset form to `getDefaultFormValue()` |
| `openModal(tpl)` / `closeModal()` | Sealed | Modal lifecycle |
| `entityName` | **Required override** | Drives default translation keys |
| `buildForm()` | **Required override** | Reactive form shape + client-side validators |
| `mapToPayload(formValue)` | **Required override** | Form value → API payload shape |
| `getListRequest / getCreateRequest / getUpdateRequest / getDeleteRequest` | **Required override** | The 4 HTTP calls |
| `getIdOf(item)` | **Required override** | How to read the entity's ID |
| `messages` | Optional (Tier 1) | Static text overrides, e.g. custom success message |
| `getSuccessMessage(action, response)` | Optional (Tier 2) | Dynamic/conditional success text |
| `getErrorMessage(err)` | Optional (Tier 2) | Custom error text extraction |
| `beforeSubmit(payload)` | Optional (Tier 2) | Transform payload right before sending |
| `mapItemToForm(item)` | Optional (Tier 2) | Custom item → form-value mapping for edit |
| `getDefaultFormValue()` | Optional (Tier 2) | Default values for add/reset |
| `afterCreateSuccess / afterUpdateSuccess / afterDeleteSuccess / afterSubmitError / afterReset` | Optional (Tier 2) | Side effects after each lifecycle event |

## 3. Full method reference — `BaseSearchComponent<T, TId>`

Use for **list/search** pages (filter form + table + row actions, no entity-submit form).

| Method | Type | Description |
|---|---|---|
| `loadResults(criteria?)` | Sealed | Fetch a page of results |
| `onSearch()` | Sealed | Reset to page 1, reload with current filter values |
| `onClearSearch()` | Sealed | Reset filter form, reload unfiltered |
| `onPageChange(page)` | Sealed | Change page, reload |
| `onSort(field)` | Sealed | Toggle sort direction on a column, reload |
| `onView(item, modalTpl)` | Sealed | Sets `selectedItem`, opens view popup |
| `onEdit(item)` | Sealed (default), Tier 2 override available | Navigates to edit page by default |
| `onDelete(item)` | Sealed | Confirm → delete → toast → reload (no-op + console warning if `getDeleteRequest` not implemented) |
| `entityName` | **Required override** | Drives default translation/message keys |
| `getSearchRequest(criteria)` | **Required override** | The list/search HTTP call |
| `getIdOf(item)` | **Required override** | How to read the entity's ID |
| `buildSearchForm()` | Optional (Tier 2) | Filter form shape (default: no filters) |
| `getDeleteRequest(id)` | Optional | Implement to enable delete from the grid; omit to disable it entirely |
| `navigateToEdit(item)` | Optional (Tier 2) | Override default router navigation |
| `messages` | Optional (Tier 1) | Delete confirmation / success text overrides |

---

## 4. Directive & component reference — show/hide, popups, alerts, validation

| Name | Kind | Solves |
|---|---|---|
| `appSubmitGuard` | Attribute directive | **Your replay-attack / duplicate-record bug.** Auto-disables a submit button while `isSubmitting` is true AND blocks the click event as backup. Bind it to the `isSubmitting` flag that already exists on every `BaseCrudComponent` — nothing to declare in your component. |
| `*appHasPermission` | Structural directive | **Show/hide links, buttons, menu items, whole sections** based on permission. Removes from the DOM entirely (not CSS-hidden). Used for Edit/Delete/Add links in the search demo. |
| `appModalTrigger` | Attribute directive | Generic "click → open this popup" for popups NOT tied to `onView()`/`onEdit()` (e.g. a Help or Filters popup). |
| `appConfirmClick` | Attribute directive | Generic "confirm before doing X" for **custom** destructive actions outside the standard delete flow (e.g. Deactivate, Cancel Request). |
| `<app-field-error>` | Component (not a directive — needs to render markup) | Displays **both client-side validator errors and server-side errors** with identical styling. Client errors come from Angular validators; server errors come from `ValidationService.applyServerErrors()`, called automatically inside every `onSubmit()` error handler. |
| `appTranslate` pipe | Pipe | `{{ 'key' | appTranslate }}` — template i18n shorthand, no service injection needed in the component. |
| `appStatusBadge` pipe | Pipe | One status → label/CSS-class mapping reused on every table across the app, instead of a `*ngSwitch` per page. |

### Why some of these are directives and one is a component
Directives (`appSubmitGuard`, `*appHasPermission`, `appModalTrigger`,
`appConfirmClick`) attach **behavior** to an element that already exists in
your template — disable it, remove it, listen for a click, show a confirm.
`<app-field-error>` needs to **render new markup** (the error text itself),
which is what components are for. This is the correct line to draw, and
it's the answer to your original question about where directives help:
**show/hide (structural directives) and click-behavior (attribute
directives) — yes; rendering new content — that's a component.**

---

## 5. Client-side vs. server-side validation, side by side

| | Client-side | Server-side |
|---|---|---|
| Where it's defined | `buildForm()` — Angular `Validators` + custom validators in `ValidationService` (`noWhitespace`, `alphaNumericCode`, `atLeastOneRequired`) | Backend API response shape: `{ errors: [{ field, message }] }` |
| Who wires it up | You, once, in `buildForm()` | Nobody — `BaseCrudComponent.onSubmit()` calls `core.applyServerErrors(form, err)` automatically on every failed request |
| How it displays | `<app-field-error>` reads `control.errors.required` etc. | Same `<app-field-error>`, reads `control.errors.serverError` |
| "Please enter at least one field" | `ValidationService.atLeastOneRequired([...])` as a group-level validator, message from `messages.validationRequired` | N/A (this one's always client-side) |

---

## 6. Files in this package

```
src/
  core/
    core-facade.service.ts          — single injectable bundling all 6 services
    services/
      toast.service.ts
      validation.service.ts
      translation.service.ts
      permission.service.ts
      modal.service.ts
      loading.service.ts
    base/
      base.component.ts             — root class (destroy$, core, t(), can())
      base-crud.component.ts        — create/edit pages
      base-search.component.ts      — search/list pages
    directives/
      submit-guard.directive.ts
      has-permission.directive.ts
      modal-trigger.directive.ts
      confirm-click.directive.ts
    components/
      field-error.component.ts
    pipes/
      translate.pipe.ts
      status-badge.pipe.ts
  examples/
    department/
      department.model.ts
      department-api.service.ts
      department-create.component.ts   — DEMO 1: full CRUD form page
      department-create.component.html
      department-search.component.ts   — DEMO 2: full search/list page
      department-search.component.html
```

## 7. Still to build (flagged in the earlier conversation, not in this package)

- `BaseDashboardComponent` (widget registration + refresh lifecycle)
- Angular Schematic to scaffold new pages already extending the right base class
- ESLint rule enforcing the Tier 1/2/3 discipline and flagging any override of a sealed method
